const getAttendanceYears = (students) => {
    let attendanceYears = [];
    students.forEach(student => {
        for(let i = student.StartYear; i <= student.EndYear; i++){
            attendanceYears.push(i)
        }
    });

    return attendanceYears;
}

const highestGpaYear = (students) => {
    let stats = [];
    students.forEach(student => {
        for(let i = 0; i < student.GPARecord.length; i++){
            let year = student.StartYear;
            let gpa = student.GPARecord[i];
            if(i === 0) {
                stats.push({[`${year}`]: gpa});
            } else {
                year += i;
                stats.push({[`${year}`]: gpa});
                
            }
        }
    });

    let attendanceYears = getAttendanceYears(students).sort();
    let firstYear = attendanceYears[0];
    let lastYear = attendanceYears[attendanceYears.length - 1];
    let highestGPAYear;
    let highestAverage = 0;

    for(let i = firstYear; i <= lastYear; i++) {
        let year = i.toString();

        const currYearAverages = stats.filter(stat => {
            return Object.keys(stat) == year;
        })

        let runningAverage = ((currYearAverages.reduce((acc, curr) => {
            return acc += curr[year];
        },0)) / currYearAverages.length).toFixed(1);

        if(runningAverage > highestAverage){
            highestAverage = runningAverage;
            highestGPAYear = year; 
        }
    }

    return parseInt(highestGPAYear);
}

const mode = (arr) => {
    return arr.sort((a,b) =>
          arr.filter(v => v === a).length
        - arr.filter(v => v === b).length
    ).pop();
}

const highestAttendanceYear = (students) => {
    let attendanceYears = getAttendanceYears(students);

    return mode(attendanceYears);
}

const highestGpa = (students) => {
    let highestGpa = [];
    students.forEach(student => {
        let sorted = student.GPARecord.sort();
        let highest = sorted[sorted.length - 1];
        highestGpa.push([student.Id, highest]);
    });

    const highestToLowest = highestGpa.sort((a,b) => b[1] - a[1]).splice(0,10).map(arr => arr[0]);

    return highestToLowest;
}

const inconsistentStudent = (students) => {
    let studentGap;
    students.forEach(student => {
        let gpaSorted = student.GPARecord.sort();

        let gap = Math.abs(gpaSorted[0] - gpaSorted[gpaSorted.length - 1]);

        if(student.Id === 1) {
            studentGap = [student.Id, gap];
        } 
        
        if(studentGap[1] && gap > studentGap[1]) {
            studentGap = [student.Id, gap]
        }
        
    });

    return students[studentGap[0]].Id;
}

async function postData(url = '', data = {}) {
const response = await fetch(url, {
    method: 'POST',
    mode: 'cors',
    headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
});
    return response.json();
}

fetch('http://apitest.sertifi.net/api/Students')
.then(res => res.json())
.then(data => {
    const students = data;

    document.getElementById("YearWithHighestAttendance").innerText = highestAttendanceYear(students);
    document.getElementById("YearWithHighestOverallGpa").innerText = highestGpaYear(students);
    document.getElementById("Top10StudentIdsWithHighestGpa").innerText = highestGpa(students);
    document.getElementById("StudentIdMostInconsistent").innerText = inconsistentStudent(students);

    return {
        "YourName": "Josh Miller",
        "YourEmail": "jmiller686@gmail.com",
        "YearWithHighestAttendance": highestAttendanceYear(students),
        "YearWithHighestOverallGpa": highestGpaYear(students),
        "Top10StudentIdsWithHighestGpa": highestGpa(students),
        "StudentIdMostInconsistent": inconsistentStudent(students)
    }
})
.then(result => console.log(result))
.finally(result => postData('http://apitest.sertifi.net/api/StudentAggregate', result));
